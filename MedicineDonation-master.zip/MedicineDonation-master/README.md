# MedicineDonation
A webapp where donors can come and donate their
unused medicines while ngo’s can accept these medicines and
provide it to needy people.
Technology Used: HTML, CSS, Bootstrap, Django, SqLite
