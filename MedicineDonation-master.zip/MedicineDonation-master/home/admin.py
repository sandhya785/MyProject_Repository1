from django.contrib import admin
from home.models import Userngo,Userdonor,Donations
# Register your models here.
admin.site.register(Userngo)
admin.site.register(Userdonor)
admin.site.register(Donations)
